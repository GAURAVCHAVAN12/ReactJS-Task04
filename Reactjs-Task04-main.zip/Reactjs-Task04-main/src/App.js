import './App.css';
import React from 'react';
import Screen from './components/Appscreen';

function App() {
  return (
    <div className='bg-dark container-fluid'>
      <Screen />
    </div>
  );
}

export default App;